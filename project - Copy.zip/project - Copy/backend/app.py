from flask import Flask, request, jsonify
from flask_cors import CORS
from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

@app.route('/api/generate', methods=['POST'])
def generate_website():
    try:
        data = request.json
        prompt = data.get('prompt')
        
        if not prompt:
            return jsonify({'error': 'No prompt provided'}), 400

        # Create a system message that instructs GPT to generate HTML/CSS
        messages = [
            {
                "role": "system",
                "content": "You are a web developer that generates clean, modern HTML and CSS code based on user descriptions. Generate only the code without any explanation or markdown."
            },
            {
                "role": "user",
                "content": f"Generate a website with the following description: {prompt}"
            }
        ]

        # Call OpenAI API
        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            temperature=0.7,
            max_tokens=2000
        )

        # Extract the generated HTML
        generated_html = response.choices[0].message.content

        return jsonify({
            'html': generated_html
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)