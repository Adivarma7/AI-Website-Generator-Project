import React, { useState } from 'react';
import { Send, RefreshCw, Download, Copy, Maximize2, Code } from 'lucide-react';
import PromptInput from './PromptInput';
import WebsitePreview from './WebsitePreview';

const Generator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedWebsite, setGeneratedWebsite] = useState<string | null>(null);
  const [showFullScreen, setShowFullScreen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-website`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate website');
      }

      const data = await response.json();
      setGeneratedWebsite(data.html);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    setPrompt('');
    setGeneratedWebsite(null);
    setError(null);
  };

  const handleExport = () => {
    if (!generatedWebsite) return;
    
    const blob = new Blob([generatedWebsite], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'generated-website.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyCode = () => {
    if (!generatedWebsite) return;
    navigator.clipboard.writeText(generatedWebsite);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="w-full lg:w-1/2">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 h-full">
                <h2 className="text-2xl font-bold mb-6">Create Your Website</h2>
                
                <PromptInput 
                  value={prompt} 
                  onChange={setPrompt} 
                  disabled={isGenerating}
                />
                
                {error && (
                  <div className="mt-4 p-4 bg-red-50 text-red-600 rounded-lg">
                    {error}
                  </div>
                )}
                
                <div className="mt-6 flex flex-col gap-4">
                  <button
                    onClick={handleGenerate}
                    disabled={!prompt.trim() || isGenerating}
                    className={`w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-white font-medium transition-colors ${
                      !prompt.trim() || isGenerating 
                        ? 'bg-gray-300 cursor-not-allowed' 
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="h-5 w-5 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        Generate Website
                      </>
                    )}
                  </button>
                  
                  {generatedWebsite && (
                    <div className="flex flex-col gap-3">
                      <div className="flex gap-2">
                        <button
                          onClick={handleReset}
                          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium transition-colors"
                        >
                          <RefreshCw className="h-4 w-4" />
                          Reset
                        </button>
                        <button
                          onClick={handleExport}
                          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-700 font-medium transition-colors"
                        >
                          <Download className="h-4 w-4" />
                          Export
                        </button>
                      </div>
                      
                      <button
                        onClick={handleCopyCode}
                        className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-900 text-white font-medium transition-colors"
                      >
                        <Code className="h-4 w-4" />
                        Copy Code
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="w-full lg:w-1/2">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 h-full">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Preview</h2>
                  {generatedWebsite && (
                    <button
                      onClick={() => setShowFullScreen(!showFullScreen)}
                      className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900"
                    >
                      <Maximize2 className="h-4 w-4" />
                      {showFullScreen ? 'Exit Fullscreen' : 'Fullscreen'}
                    </button>
                  )}
                </div>
                
                <WebsitePreview
                  html={generatedWebsite}
                  isLoading={isGenerating}
                  fullScreen={showFullScreen}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Generator;