import React from 'react';
import { Code, Sparkles, Zap } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 text-blue-700 text-sm font-medium mb-6">
            <Sparkles className="h-4 w-4" />
            <span>AI-Powered Website Creation</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-teal-500 bg-clip-text text-transparent">
            Create Beautiful Websites with Just a Prompt
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Turn your ideas into fully functional websites in seconds. No coding required.
            Just describe what you want, and our AI will build it for you.
          </p>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-4">
            <button className="w-full md:w-auto flex items-center justify-center gap-2 px-8 py-3 text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-all transform hover:scale-105">
              <Zap className="h-5 w-5" />
              <span className="font-medium">Create Your Website</span>
            </button>
            
            <button className="w-full md:w-auto flex items-center justify-center gap-2 px-8 py-3 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-all">
              <Code className="h-5 w-5" />
              <span className="font-medium">View Examples</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;