import React from 'react';
import { RefreshCw, Smartphone, Tablet, Monitor } from 'lucide-react';

interface WebsitePreviewProps {
  html: string | null;
  isLoading: boolean;
  fullScreen: boolean;
}

const WebsitePreview: React.FC<WebsitePreviewProps> = ({ html, isLoading, fullScreen }) => {
  const [viewportSize, setViewportSize] = React.useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  
  const getViewportClass = () => {
    switch (viewportSize) {
      case 'mobile':
        return 'w-full max-w-[375px] mx-auto h-[600px]';
      case 'tablet':
        return 'w-full max-w-[768px] mx-auto h-[600px]';
      case 'desktop':
        return 'w-full h-[600px]';
      default:
        return 'w-full h-[600px]';
    }
  };
  
  return (
    <div className={`flex flex-col ${fullScreen ? 'fixed inset-0 z-50 bg-white p-6' : ''}`}>
      {(html || isLoading) && (
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewportSize('mobile')}
              className={`p-2 rounded-lg ${
                viewportSize === 'mobile' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
              title="Mobile View"
            >
              <Smartphone className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewportSize('tablet')}
              className={`p-2 rounded-lg ${
                viewportSize === 'tablet' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
              title="Tablet View"
            >
              <Tablet className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewportSize('desktop')}
              className={`p-2 rounded-lg ${
                viewportSize === 'desktop' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
              title="Desktop View"
            >
              <Monitor className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}
      
      <div className={`flex-grow ${!html && !isLoading ? 'flex items-center justify-center' : ''}`}>
        {isLoading ? (
          <div className="h-full flex flex-col items-center justify-center bg-gray-50 rounded-lg border border-gray-200">
            <RefreshCw className="h-8 w-8 text-blue-500 animate-spin mb-4" />
            <p className="text-gray-600 font-medium">Generating your website...</p>
          </div>
        ) : html ? (
          <div className={`overflow-hidden border border-gray-200 rounded-lg ${getViewportClass()}`}>
            <iframe
              srcDoc={html}
              title="Website Preview"
              className="w-full h-full"
              sandbox="allow-same-origin allow-scripts"
            />
          </div>
        ) : (
          <div className="text-center p-6">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Monitor className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-500">Enter a prompt and click "Generate" to see your website preview</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default WebsitePreview;