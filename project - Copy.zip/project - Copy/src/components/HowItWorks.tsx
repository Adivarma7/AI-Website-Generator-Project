import React from 'react';
import { MessageSquare, Eye, Code, Zap } from 'lucide-react';

interface StepProps {
  icon: React.ReactNode;
  number: number;
  title: string;
  description: string;
}

const Step: React.FC<StepProps> = ({ icon, number, title, description }) => {
  return (
    <div className="flex flex-col items-center text-center">
      <div className="relative">
        <div className="w-16 h-16 flex items-center justify-center rounded-full bg-blue-600 text-white mb-4">
          {icon}
        </div>
        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center text-sm font-bold">
          {number}
        </div>
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <MessageSquare className="h-7 w-7" />,
      number: 1,
      title: "Describe Your Vision",
      description: "Tell our AI what kind of website you want to create. Be as specific or general as you like."
    },
    {
      icon: <Zap className="h-7 w-7" />,
      number: 2,
      title: "AI Generates Your Site",
      description: "Our powerful AI analyzes your prompt and creates a custom website based on your description."
    },
    {
      icon: <Eye className="h-7 w-7" />,
      number: 3,
      title: "Preview & Refine",
      description: "See your website in real-time and make adjustments until it's exactly what you want."
    },
    {
      icon: <Code className="h-7 w-7" />,
      number: 4,
      title: "Export & Launch",
      description: "Download your website code or deploy directly to your domain with a single click."
    }
  ];

  return (
    <section id="how-it-works" className="py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">How WebGenius Works</h2>
          <p className="text-lg text-gray-600">
            Creating your dream website is simple and intuitive with our four-step process.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <Step
              key={index}
              icon={step.icon}
              number={step.number}
              title={step.title}
              description={step.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;