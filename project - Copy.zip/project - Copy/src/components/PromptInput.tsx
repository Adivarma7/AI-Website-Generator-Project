import React from 'react';
import { HelpCircle } from 'lucide-react';

interface PromptInputProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

const PromptInput: React.FC<PromptInputProps> = ({ value, onChange, disabled = false }) => {
  const examplePrompts = [
    "A modern portfolio website for a graphic designer with a dark theme",
    "An e-commerce landing page for organic skincare products",
    "A restaurant website with online reservation system",
    "A tech startup homepage with product showcase"
  ];

  const handleExampleClick = (example: string) => {
    onChange(example);
  };

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-start gap-2 mb-2">
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-700">
            Describe your website
          </label>
          <button
            type="button"
            className="text-gray-400 hover:text-gray-600"
            title="Prompt Tips"
          >
            <HelpCircle className="h-4 w-4" />
          </button>
        </div>
        
        <textarea
          id="prompt"
          rows={5}
          placeholder="Describe the website you want to create. Include details about the type of site, color scheme, features, and any specific sections you want."
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none disabled:bg-gray-100 disabled:text-gray-500"
        />
        
        <p className="mt-2 text-sm text-gray-500 flex justify-between">
          <span>Be specific for better results.</span>
          <span>{value.length}/500 characters</span>
        </p>
      </div>
      
      <div>
        <p className="text-sm font-medium text-gray-700 mb-2">Example prompts:</p>
        <div className="flex flex-wrap gap-2">
          {examplePrompts.map((example, index) => (
            <button
              key={index}
              type="button"
              onClick={() => handleExampleClick(example)}
              disabled={disabled}
              className="inline-block px-3 py-1 text-xs rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed truncate max-w-full"
            >
              {example}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PromptInput;